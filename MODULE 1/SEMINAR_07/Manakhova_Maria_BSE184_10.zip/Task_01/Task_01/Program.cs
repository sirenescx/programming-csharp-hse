﻿/*Манахова Мария
 * БПИ 184
 * Вариант 10
 * 19.10.2018 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_01
{
    class Program
    {
        static double MinMaxofArr(int[] a, ref int min, ref int max)   ///Метод для нахождения минимального и максимального четного элемента при их наличии
        {
            int count = 0;
            min = int.MaxValue;
            max = 0;
            for (int i = 0; i < a.Length; i++)
            {
                if (a[i] % 2 != 0) count++; 
            }
            if (count == a.Length) return -1;
            else
            {
                for (int i = 0; i < a.Length; i++)
                {
                    if (a[i] % 2 == 0 && a[i] < min) min = a[i];
                    if (a[i] % 2 == 0 && a[i] > max) max = a[i];
                }
            }
            return 0;
            }

        static int[] FillArr(int n, int k)   ///Метод для заполнения массива
        {
            int[] ar = new int[n];
            Random rand = new Random();
            if (k == 1)
            {
                for (int i = 0; i < ar.Length; i++)
                    ar[i] = rand.Next(0, 100);
            }
            if (k == 2)
            {
                for (int i = 0; i < ar.Length; i++)
                    do Console.WriteLine($"Введите элемент массива 0<=a[{i}]<100: ");
               while (!int.TryParse(Console.ReadLine(), out ar[i]) || ar[i] < 0 || ar[i] >= 100);
            }
            return ar;
        }

        static void Input(out int n, out int k)   ///метод для ввода размера массива и числа k
        {
            do Console.WriteLine("Введите размер массива, целое число > 0: ");
            while (!int.TryParse(Console.ReadLine(), out n) || n < 0);
            do Console.WriteLine("Введите число K (1 или 2)");
            while (!int.TryParse(Console.ReadLine(), out k) || (k < 1) || k > 2);
        }

        static void ArrOutput(int[] ar)       ///Метод для вывода исходного и отсортированного по убыванию массива
        {
            Console.WriteLine("Исходный массив: ");
            for (int i = 0; i < ar.Length; i++)
                Console.WriteLine(ar[i]);
                Array.Sort(ar);
                Array.Reverse(ar);
            Console.WriteLine("Отсортированный по убыванию массив: ");
            for (int i = 0; i < ar.Length; i++)
                Console.WriteLine(ar[i]);
        }

        static void ArrLessThanFOutput(int[] arLessThanF)    ///Метод для вывода всех чисел массива, меньших F
        {
            Console.WriteLine("Значения массива <= f: ");
            for (int i = 0; i < arLessThanF.Length; i++)
                Console.WriteLine(arLessThanF[i]);
        }

        static int [] LessThanF(int[] ar, double f)     ///Метод для нахождения чисел массива, меньших или равных F
        {
            int[] aLessThanF = new int[ar.Length];

            for (int i = 0; i < ar.Length; i++)
                if (ar[i] <= f)
                {
                    aLessThanF[i] = ar[i];
                }

            int m = 0; 
            for (int k = 0; k < ar.Length; k++)
            {
                if (!(ar[k] != 0 & aLessThanF[k] == 0))
                    aLessThanF[m++] = aLessThanF[k];
            }
            if (m > 0) Array.Resize(ref aLessThanF, m);
            return aLessThanF;
        }

        static void Main(string[] args)
        {
            int n, k;
            do
            {
                Console.WriteLine("Если программа запрашивает ввод тех же данных снова, значит произошла ошибка ввода");
                Input(out n, out k);
                double f;

                int[] ar = FillArr(n, k);
                ArrOutput(ar);
                int min = 0;
                int max = 0;
                Console.WriteLine(MinMaxofArr(ar, ref min, ref max));
                Console.WriteLine($"Минимальное четное число = {min}, максимальное четное число = {max}");
                do Console.WriteLine("Введите вещественное число F: ");
                while (!double.TryParse(Console.ReadLine(), out f));
                int[] arLessThanF = LessThanF(ar, f);
                ArrLessThanFOutput(arLessThanF);
                Console.WriteLine("Для продолжения нажмите любую клавишу, для выхода нажмите ESCAPE");
            } while (Console.ReadKey().Key != ConsoleKey.Escape);
        }
    }
}
